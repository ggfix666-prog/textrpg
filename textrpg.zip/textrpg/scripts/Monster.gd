extends Node
## База монстров для шести локаций. Armor — процент поглощения урона.
const PLAYER_LEVEL_GROWTH: float = 0.15
const BOSS_CHANCE: float = 0.10

const LOCATIONS: Array[Dictionary] = [
	{
		"id": "start", "name": "Колизей", "difficulty": 1.0,
		"monsters": [
			{"name": "Крыса-мутант", "hp": 30, "damage": 5, "armor": 0, "xp_reward": 5, "gold_reward": 3, "is_boss": false, "sprite_path": ""},
			{"name": "Гоблин-мародёр", "hp": 45, "damage": 8, "armor": 5, "xp_reward": 8, "gold_reward": 5, "is_boss": false, "sprite_path": ""},
			{"name": "Одичавший пёс", "hp": 40, "damage": 10, "armor": 0, "xp_reward": 7, "gold_reward": 4, "is_boss": false, "sprite_path": ""},
			{"name": "Гладиатор-новичок", "hp": 60, "damage": 12, "armor": 15, "xp_reward": 12, "gold_reward": 10, "is_boss": false, "sprite_path": ""},
			{"name": "Песчаный скорпион", "hp": 35, "damage": 15, "armor": 5, "xp_reward": 10, "gold_reward": 6, "is_boss": false, "sprite_path": ""},
			{"name": "Скелет-воин", "hp": 50, "damage": 10, "armor": 20, "xp_reward": 10, "gold_reward": 8, "is_boss": false, "sprite_path": ""},
			{"name": "Гарпия", "hp": 40, "damage": 12, "armor": 5, "xp_reward": 12, "gold_reward": 7, "is_boss": false, "sprite_path": ""},
			{"name": "Берсерк", "hp": 70, "damage": 18, "armor": 0, "xp_reward": 15, "gold_reward": 12, "is_boss": false, "sprite_path": ""},
			{"name": "Минотавр", "hp": 300, "damage": 25, "armor": 25, "xp_reward": 100, "gold_reward": 150, "is_boss": true, "sprite_path": ""}
		]
	},
	{
		"id": "forest", "name": "Тёмный Лес", "difficulty": 1.5,
		"monsters": [
			{"name": "Гигантский паук", "hp": 80, "damage": 15, "armor": 5, "xp_reward": 20, "gold_reward": 15, "is_boss": false, "sprite_path": ""},
			{"name": "Лесной волк", "hp": 90, "damage": 18, "armor": 10, "xp_reward": 22, "gold_reward": 18, "is_boss": false, "sprite_path": ""},
			{"name": "Разбойник", "hp": 100, "damage": 20, "armor": 15, "xp_reward": 25, "gold_reward": 20, "is_boss": false, "sprite_path": ""},
			{"name": "Гоблин-лучник", "hp": 70, "damage": 22, "armor": 5, "xp_reward": 25, "gold_reward": 18, "is_boss": false, "sprite_path": ""},
			{"name": "Кровососущая пиявка", "hp": 110, "damage": 10, "armor": 10, "xp_reward": 20, "gold_reward": 12, "is_boss": false, "sprite_path": ""},
			{"name": "Гриб-мутант", "hp": 120, "damage": 5, "armor": 30, "xp_reward": 18, "gold_reward": 10, "is_boss": false, "sprite_path": ""},
			{"name": "Древень", "hp": 150, "damage": 15, "armor": 40, "xp_reward": 30, "gold_reward": 25, "is_boss": false, "sprite_path": ""},
			{"name": "Король Гоблинов", "hp": 600, "damage": 35, "armor": 20, "xp_reward": 250, "gold_reward": 400, "is_boss": true, "sprite_path": ""}
		]
	},
	{
		"id": "ruins", "name": "Руины", "difficulty": 2.5,
		"monsters": [
			{"name": "Скелет-маг", "hp": 200, "damage": 40, "armor": 10, "xp_reward": 50, "gold_reward": 40, "is_boss": false, "sprite_path": ""},
			{"name": "Каменный голем", "hp": 350, "damage": 30, "armor": 50, "xp_reward": 60, "gold_reward": 50, "is_boss": false, "sprite_path": ""},
			{"name": "Призрак", "hp": 180, "damage": 45, "armor": 0, "xp_reward": 55, "gold_reward": 45, "is_boss": false, "sprite_path": ""},
			{"name": "Элементаль воды", "hp": 220, "damage": 42, "armor": 20, "xp_reward": 55, "gold_reward": 45, "is_boss": false, "sprite_path": ""},
			{"name": "Мумия", "hp": 280, "damage": 35, "armor": 25, "xp_reward": 60, "gold_reward": 50, "is_boss": false, "sprite_path": ""},
			{"name": "Глаз-наблюдатель", "hp": 250, "damage": 50, "armor": 15, "xp_reward": 65, "gold_reward": 60, "is_boss": false, "sprite_path": ""},
			{"name": "Проклятый жрец", "hp": 200, "damage": 25, "armor": 20, "xp_reward": 50, "gold_reward": 80, "is_boss": false, "sprite_path": ""},
			{"name": "Лич-Архимаг", "hp": 1200, "damage": 70, "armor": 30, "xp_reward": 800, "gold_reward": 1200, "is_boss": true, "sprite_path": ""}
		]
	},
	{
		"id": "crypt", "name": "Забытый Склеп", "difficulty": 4.0,
		"monsters": [
			{"name": "Зомби", "hp": 500, "damage": 60, "armor": 20, "xp_reward": 120, "gold_reward": 100, "is_boss": false, "sprite_path": ""},
			{"name": "Летучая мышь-вампир", "hp": 400, "damage": 70, "armor": 10, "xp_reward": 110, "gold_reward": 90, "is_boss": false, "sprite_path": ""},
			{"name": "Упырь", "hp": 550, "damage": 65, "armor": 25, "xp_reward": 130, "gold_reward": 110, "is_boss": false, "sprite_path": ""},
			{"name": "Призрак-плакальщица", "hp": 450, "damage": 80, "armor": 0, "xp_reward": 140, "gold_reward": 120, "is_boss": false, "sprite_path": ""},
			{"name": "Крысиный король", "hp": 600, "damage": 55, "armor": 30, "xp_reward": 120, "gold_reward": 100, "is_boss": false, "sprite_path": ""},
			{"name": "Отрекшийся рыцарь", "hp": 700, "damage": 65, "armor": 60, "xp_reward": 150, "gold_reward": 150, "is_boss": false, "sprite_path": ""},
			{"name": "Некромант", "hp": 500, "damage": 75, "armor": 15, "xp_reward": 140, "gold_reward": 160, "is_boss": false, "sprite_path": ""},
			{"name": "Граф-Вампир", "hp": 2500, "damage": 120, "armor": 40, "xp_reward": 2000, "gold_reward": 3000, "is_boss": true, "sprite_path": ""}
		]
	},
	{
		"id": "death_halls", "name": "Чертоги Смерти", "difficulty": 6.0,
		"monsters": [
			{"name": "Демон-пехота", "hp": 1000, "damage": 120, "armor": 30, "xp_reward": 300, "gold_reward": 250, "is_boss": false, "sprite_path": ""},
			{"name": "Адская гончая", "hp": 900, "damage": 140, "armor": 20, "xp_reward": 280, "gold_reward": 220, "is_boss": false, "sprite_path": ""},
			{"name": "Суккуб", "hp": 800, "damage": 130, "armor": 10, "xp_reward": 320, "gold_reward": 300, "is_boss": false, "sprite_path": ""},
			{"name": "Костяной дракон", "hp": 1300, "damage": 150, "armor": 50, "xp_reward": 400, "gold_reward": 350, "is_boss": false, "sprite_path": ""},
			{"name": "Палач", "hp": 1100, "damage": 180, "armor": 40, "xp_reward": 350, "gold_reward": 320, "is_boss": false, "sprite_path": ""},
			{"name": "Огненный элементаль", "hp": 950, "damage": 160, "armor": 15, "xp_reward": 310, "gold_reward": 280, "is_boss": false, "sprite_path": ""},
			{"name": "Грешник", "hp": 1000, "damage": 110, "armor": 25, "xp_reward": 290, "gold_reward": 240, "is_boss": false, "sprite_path": ""},
			{"name": "Владыка Демонов", "hp": 5000, "damage": 250, "armor": 50, "xp_reward": 5000, "gold_reward": 8000, "is_boss": true, "sprite_path": ""}
		]
	},
	{
		"id": "dragon", "name": "Логово Дракона", "difficulty": 10.0,
		"monsters": [
			{"name": "Кобольд-копатель", "hp": 2000, "damage": 200, "armor": 20, "xp_reward": 800, "gold_reward": 700, "is_boss": false, "sprite_path": ""},
			{"name": "Ящер-переросток", "hp": 2500, "damage": 220, "armor": 40, "xp_reward": 850, "gold_reward": 750, "is_boss": false, "sprite_path": ""},
			{"name": "Драконорожденный", "hp": 3000, "damage": 250, "armor": 60, "xp_reward": 900, "gold_reward": 800, "is_boss": false, "sprite_path": ""},
			{"name": "Саламандра", "hp": 2800, "damage": 260, "armor": 30, "xp_reward": 900, "gold_reward": 850, "is_boss": false, "sprite_path": ""},
			{"name": "Молодой дракон", "hp": 3500, "damage": 300, "armor": 50, "xp_reward": 1200, "gold_reward": 1000, "is_boss": false, "sprite_path": ""},
			{"name": "Огнегривый грифон", "hp": 3200, "damage": 280, "armor": 40, "xp_reward": 1100, "gold_reward": 950, "is_boss": false, "sprite_path": ""},
			{"name": "Древний Дракон", "hp": 15000, "damage": 500, "armor": 80, "xp_reward": 15000, "gold_reward": 25000, "is_boss": true, "sprite_path": ""}
		]
	}
]

var _rng := RandomNumberGenerator.new()

func _ready() -> void:
	_rng.randomize()

func location_index(location_id: String) -> int:
	for i in range(LOCATIONS.size()):
		if str(LOCATIONS[i]["id"]) == location_id:
			return i
	return 0

func generate_monster(location_index: int, player_level: int) -> Dictionary:
	if location_index < 0 or location_index >= LOCATIONS.size():
		push_error("MonsterDB: неверный индекс локации: %d" % location_index)
		return {}
	var location: Dictionary = LOCATIONS[location_index]
	var regular: Array[Dictionary] = []
	var bosses: Array[Dictionary] = []
	for item in location["monsters"]:
		if bool(item["is_boss"]):
			bosses.append(item)
		else:
			regular.append(item)
	var selected: Dictionary
	if not bosses.is_empty() and _rng.randf() < BOSS_CHANCE:
		selected = bosses[_rng.randi_range(0, bosses.size() - 1)]
	else:
		selected = regular[_rng.randi_range(0, regular.size() - 1)]
	var generated: Dictionary = scale_monster(selected, float(location["difficulty"]), player_level)
	generated["location_id"] = str(location["id"])
	return generated

func generate_boss(location_index: int, player_level: int) -> Dictionary:
	if location_index < 0 or location_index >= LOCATIONS.size():
		return {}
	var bosses: Array[Dictionary] = []
	for item in LOCATIONS[location_index]["monsters"]:
		if bool(item["is_boss"]):
			bosses.append(item)
	if bosses.is_empty():
		return {}
	var generated: Dictionary = scale_monster(bosses[0], float(LOCATIONS[location_index]["difficulty"]), player_level)
	generated["location_id"] = str(LOCATIONS[location_index]["id"])
	return generated

func scale_monster(base: Dictionary, difficulty: float, player_level: int) -> Dictionary:
	var result: Dictionary = base.duplicate(true)
	var safe_level: int = maxi(1, player_level)
	var level_multiplier: float = 1.0 + (safe_level * PLAYER_LEVEL_GROWTH)
	var multiplier: float = difficulty * level_multiplier
	result["hp"] = maxi(1, roundi(float(base["hp"]) * multiplier))
	result["damage"] = maxi(1, roundi(float(base["damage"]) * multiplier))
	result["xp_reward"] = maxi(0, roundi(float(base["xp_reward"]) * multiplier))
	result["gold_reward"] = maxi(0, roundi(float(base["gold_reward"]) * multiplier))
	result["armor"] = clampi(int(base["armor"]), 0, 100)
	result["location_multiplier"] = difficulty
	result["level_multiplier"] = level_multiplier
	result["total_multiplier"] = multiplier
	return result

func get_location_name(location_index: int) -> String:
	if location_index < 0 or location_index >= LOCATIONS.size():
		return ""
	return str(LOCATIONS[location_index]["name"])
