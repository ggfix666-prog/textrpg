extends Control
# Главное меню (вертикальный экран): название сверху, четыре крупные кнопки по центру, «Выход» внизу.

var layout_root: Control
var settings_dialog: AcceptDialog
var volume_slider: HSlider
var new_game_dialog: ConfirmationDialog


func _ready() -> void:
	Style.add_bg(self)
	_add_backdrop()
	layout_root = Control.new()
	layout_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(layout_root)
	_build_dialogs()
	get_viewport().size_changed.connect(_rebuild_layout)
	_rebuild_layout()


# Тёмная картинка арены на фоне (если файла нет, остаётся просто тёмный фон)
func _add_backdrop() -> void:
	var path := "res://assets/locations/coliseum.jpg"
	if not ResourceLoader.exists(path):
		return
	var tex := TextureRect.new()
	tex.texture = load(path) as Texture2D
	tex.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	tex.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tex.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	tex.modulate = Color(0.38, 0.32, 0.28, 1.0)
	tex.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(tex)


func _rebuild_layout() -> void:
	if not is_instance_valid(layout_root):
		return
	for child in layout_root.get_children():
		child.queue_free()
	_build_portrait(get_viewport_rect().size)


func _build_portrait(view: Vector2) -> void:
	var margin: float = view.x * 0.08
	var width: float = view.x - margin * 2.0

	# Заголовок
	var title := VBoxContainer.new()
	title.position = Vector2(margin, view.y * 0.07)
	title.size = Vector2(width, view.y * 0.20)
	title.alignment = BoxContainer.ALIGNMENT_CENTER
	title.add_theme_constant_override("separation", 10)
	layout_root.add_child(title)
	title.add_child(Style.make_title("ХРОНИКИ\nМРАКА", clampi(int(view.x * 0.115), 56, 90)))
	title.add_child(Style.lbl("[center][color=#c9a961]ТЁМНОЕ ФЭНТЕЗИ • RPG[/color][/center]", 26))

	# Панель с кнопками
	var panel := PanelContainer.new()
	panel.position = Vector2(margin, view.y * 0.34)
	panel.size = Vector2(width, 10.0)
	panel.add_theme_stylebox_override("panel", _menu_panel_style())
	layout_root.add_child(panel)
	panel.add_child(_make_buttons())

	# Выход внизу
	var exit := Style.btn("ВЫХОД", Style.DARK, 92, 30)
	exit.position = Vector2(margin, view.y - 92.0 - 56.0)
	exit.size = Vector2(width, 92.0)
	exit.pressed.connect(func(): get_tree().quit())
	layout_root.add_child(exit)


func _menu_panel_style() -> StyleBoxFlat:
	var box := StyleBoxFlat.new()
	box.bg_color = Color(0.10, 0.08, 0.06, 0.90)
	box.border_color = Style.GOLD
	box.set_border_width_all(3)
	box.set_corner_radius_all(14)
	box.content_margin_left = 18
	box.content_margin_right = 18
	box.content_margin_top = 18
	box.content_margin_bottom = 18
	return box


func _make_buttons() -> VBoxContainer:
	var menu := VBoxContainer.new()
	menu.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	menu.add_theme_constant_override("separation", 16)

	var new_btn := Style.btn("НОВАЯ ИГРА", Style.BLOOD, 108, 36)
	new_btn.pressed.connect(_confirm_new_game)
	menu.add_child(new_btn)

	var cont_btn := Style.btn("ПРОДОЛЖИТЬ", Style.MOSS, 108, 36)
	cont_btn.disabled = not SaveManager.has_save()
	cont_btn.pressed.connect(_on_continue)
	menu.add_child(cont_btn)

	var online := Style.btn("ОНЛАЙН", Style.PLATE, 108, 36)
	online.pressed.connect(_on_online)
	menu.add_child(online)

	var settings := Style.btn("НАСТРОЙКИ", Style.PLATE, 108, 36)
	settings.pressed.connect(func(): settings_dialog.popup_centered())
	menu.add_child(settings)
	return menu


func _build_dialogs() -> void:
	new_game_dialog = ConfirmationDialog.new()
	new_game_dialog.title = "Начать новую игру?"
	new_game_dialog.dialog_text = "Новая игра заменит текущий прогресс. Продолжить?"
	new_game_dialog.min_size = Vector2i(560, 240)
	new_game_dialog.confirmed.connect(func(): get_tree().change_scene_to_file("res://scenes/ClassSelect.tscn"))
	add_child(new_game_dialog)

	settings_dialog = AcceptDialog.new()
	settings_dialog.title = "Настройки"
	settings_dialog.dialog_text = "Громкость звука"
	settings_dialog.min_size = Vector2i(560, 300)
	var content := VBoxContainer.new()
	content.add_theme_constant_override("separation", 16)
	settings_dialog.add_child(content)
	volume_slider = HSlider.new()
	volume_slider.min_value = 0.0
	volume_slider.max_value = 1.0
	volume_slider.step = 0.05
	volume_slider.custom_minimum_size = Vector2(0, 64)
	volume_slider.value = db_to_linear(AudioServer.get_bus_volume_db(0))
	volume_slider.value_changed.connect(_on_volume_changed)
	content.add_child(volume_slider)
	var hint := Label.new()
	hint.text = "Громкость меняется сразу."
	content.add_child(hint)
	add_child(settings_dialog)


func _confirm_new_game() -> void:
	if SaveManager.has_save():
		new_game_dialog.popup_centered()
	else:
		get_tree().change_scene_to_file("res://scenes/ClassSelect.tscn")


func _on_volume_changed(value: float) -> void:
	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(value, 0.001)))


func _on_continue() -> void:
	if SaveManager.load_game():
		get_tree().change_scene_to_file("res://scenes/Explore.tscn")
	else:
		get_tree().change_scene_to_file("res://scenes/ClassSelect.tscn")


func _on_online() -> void:
	if SaveManager.has_save():
		SaveManager.load_game()
	get_tree().change_scene_to_file("res://scenes/OnlineMenu.tscn")
