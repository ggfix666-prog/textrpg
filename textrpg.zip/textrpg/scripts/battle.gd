extends Control
# Бой с врагом (оффлайн). В начале хода выпадает 1-3 действия: Удар / Зелье / Способность.
# Игрок набирает комбо и жмёт «Закончить ход» — затем отвечает враг.

var stats_label: RichTextLabel
var logv
var bottom: VBoxContainer
var bottom_scroll: ScrollContainer
var battle_stage: Control
var hero_sprite: TextureRect
var foe_sprite: TextureRect
var hero_fallback: Label
var foe_fallback: Label
var hero_home := Vector2.ZERO
var foe_home := Vector2.ZERO

const HERO_SPRITES := {
	"gladiator": "res://assets/characters/gladiator.png",
	"mage": "res://assets/characters/mage.png",
	"vampire": "res://assets/characters/vampire.png",
	"archer": "res://assets/characters/archer.png",
	"hunter": "res://assets/characters/hunter.png",
}
const FOE_SPRITES := {
	"Крыса-мутант": "mutant_rat.png", "Гоблин-мародёр": "goblin.png",
	"Одичавший пёс": "feral_dog.png", "Гладиатор-новичок": "rookie_gladiator.png",
	"Песчаный скорпион": "sand_scorpion.png", "Скелет-воин": "skeleton_warrior.png",
	"Гарпия": "harpy.png", "Берсерк": "berserker.png", "Минотавр": "minotaur.png",
	"Гоблин": "goblin.png", "Крыса": "mutant_rat.png", "Король гоблинов": "goblin_king.png",
}

var P: Dictionary = {}
var E: Dictionary = {}
var phase := "pick"            # pick / turn / busy / over
var queue: Array = []
var actions_total := 1
var turn := 1
var potion_menu := false
var level_before := 1


func _ready() -> void:
	randomize()
	if SaveManager.data["class_id"] == "":
		get_tree().change_scene_to_file("res://scenes/MainMenu.tscn")
		return
	level_before = SaveManager.data["level"]
	var col := Style.screen(self, "")
	stats_label = Style.lbl("", 26)
	col.add_child(stats_label)
	_create_battle_stage(col)
	logv = Style.make_log()
	col.add_child(logv)
	logv.custom_minimum_size.y = _log_height()
	bottom_scroll = ScrollContainer.new()
	bottom_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bottom_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	bottom_scroll.custom_minimum_size.y = _controls_height()
	bottom_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	col.add_child(bottom_scroll)
	bottom = VBoxContainer.new()
	bottom.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bottom.add_theme_constant_override("separation", 7)
	bottom_scroll.add_child(bottom)

	P = Combat.hero_fighter()
	E = SaveManager.encounter.duplicate(true)
	if E.is_empty():
		E = WorldData.make_enemy("goblin", int(SaveManager.data["level"]))
	E = Combat.fix(E)
	_load_battle_sprites()
	if E["boss"]:
		_log("[color=#ff5a5a][b]БОСС![/b][/color] Перед вами [color=#c9a961]%s[/color] (ур. %d)." % [E["name"], E["lvl"]])
	else:
		_log("Из тени выступает [color=#c9a961]%s[/color] (ур. %d)." % [E["name"], E["lvl"]])
	var pre: Array = []
	if E["first"] == "player":
		pre.append("[color=#c9a961]Вы нападаете из засады![/color]")
		Combat.attack(P, E, 1.0, pre, true)
	elif E["first"] == "enemy":
		pre.append("Враг не дал вам уйти и бьёт первым!")
		Combat.enemy_turn(E, P, pre)
	_flush(pre)
	if int(E["hp"]) <= 0:
		_victory()
		return
	if int(P["hp"]) <= 0:
		_defeat()
		return
	_log("Выбери способность на этот бой. Сменить её в бою нельзя.")
	_refresh()


func _stage_height() -> float:
	var v := get_viewport_rect().size
	return clampf(v.y * (0.25 if v.x <= v.y else 0.34), 190.0, 330.0)

func _controls_height() -> float:
	var v := get_viewport_rect().size
	return clampf(v.y * (0.30 if v.x <= v.y else 0.40), 380.0, 430.0)

func _log_height() -> float:
	var v := get_viewport_rect().size
	return clampf(v.y * (0.14 if v.x <= v.y else 0.16), 150.0, 230.0)

func _on_viewport_resized() -> void:
	if battle_stage != null:
		battle_stage.custom_minimum_size.y = _stage_height()
	if bottom_scroll != null:
		bottom_scroll.custom_minimum_size.y = _controls_height()
	if logv != null:
		logv.custom_minimum_size.y = _log_height()
	_layout_battle_stage()

func _create_battle_stage(parent: VBoxContainer) -> void:
	battle_stage = Control.new()
	battle_stage.name = "BattleStage"
	battle_stage.custom_minimum_size = Vector2(0, _stage_height())
	get_viewport().size_changed.connect(_on_viewport_resized)
	battle_stage.resized.connect(_layout_battle_stage)
	battle_stage.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	battle_stage.clip_contents = true
	parent.add_child(battle_stage)
	var bg := TextureRect.new()
	bg.name = "ArenaBackground"
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	bg.stretch_mode = TextureRect.STRETCH_SCALE
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var bg_path := "res://assets/locations/coliseum.jpg"
	if ResourceLoader.exists(bg_path):
		bg.texture = load(bg_path) as Texture2D
	else:
		var fill := ColorRect.new()
		fill.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		fill.color = Color("#49351f")
		battle_stage.add_child(fill)
	battle_stage.add_child(bg)
	hero_sprite = _make_fighter_sprite("HeroSprite")
	foe_sprite = _make_fighter_sprite("EnemySprite")
	battle_stage.add_child(hero_sprite)
	battle_stage.add_child(foe_sprite)
	hero_fallback = _make_fallback("ГЕРОЙ")
	foe_fallback = _make_fallback("ВРАГ")
	battle_stage.add_child(hero_fallback)
	battle_stage.add_child(foe_fallback)
	_layout_battle_stage()

func _make_fighter_sprite(node_name: String) -> TextureRect:
	var sprite := TextureRect.new()
	sprite.name = node_name
	sprite.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	sprite.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	sprite.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return sprite

func _make_fallback(label_text: String) -> Label:
	var label := Label.new()
	label.text = label_text
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.add_theme_color_override("font_color", Color("#f3e7c9"))
	label.add_theme_font_size_override("font_size", 22)
	return label

func _layout_battle_stage() -> void:
	# Сигнал resized может сработать сразу после создания BattleStage,
	# ещё до создания спрайтов и запасных Label. В таком случае выходим,
	# чтобы не обращаться к Nil.position и не прерывать запуск боя.
	if battle_stage == null:
		return
	if hero_sprite == null or foe_sprite == null:
		return
	if hero_fallback == null or foe_fallback == null:
		return

	var w := maxf(battle_stage.size.x, 320.0)
	var h := maxf(battle_stage.size.y, 160.0)
	hero_home = Vector2(w * 0.02, h * 0.04)
	foe_home = Vector2(w * 0.64, h * 0.04)
	hero_sprite.position = hero_home
	hero_sprite.size = Vector2(w * 0.34, h * 0.92)
	foe_sprite.position = foe_home
	foe_sprite.size = Vector2(w * 0.34, h * 0.92)
	hero_fallback.position = Vector2(w * 0.02, h * 0.65)
	hero_fallback.size = Vector2(w * 0.34, 42)
	foe_fallback.position = Vector2(w * 0.64, h * 0.65)
	foe_fallback.size = Vector2(w * 0.34, 42)

func _load_battle_sprites() -> void:
	var class_id := str(SaveManager.data.get("class_id", "gladiator"))
	var hero_path := str(HERO_SPRITES.get(class_id, ""))
	var hero_tex: Texture2D = load(hero_path) as Texture2D if hero_path != "" and ResourceLoader.exists(hero_path) else null
	hero_sprite.texture = hero_tex
	hero_sprite.visible = hero_tex != null
	hero_fallback.visible = hero_tex == null
	var foe_name := str(E.get("name", E.get("monster_id", "")))
	var foe_id := str(E.get("monster_id", E.get("id", "")))
	var foe_path := str(FOE_SPRITES.get(foe_name, FOE_SPRITES.get(foe_id, "")))
	if foe_path == "":
		var simple := foe_name.to_lower().replace(" ", "_").replace("-", "_")
		foe_path = simple + ".png"
	if foe_path != "" and not foe_path.begins_with("res://"):
		foe_path = "res://assets/monsters/" + foe_path
	var foe_tex: Texture2D = load(foe_path) as Texture2D if foe_path != "" and ResourceLoader.exists(foe_path) else null
	foe_sprite.texture = foe_tex
	foe_sprite.visible = foe_tex != null
	foe_fallback.text = str(E.get("name", "ВРАГ"))
	foe_fallback.visible = foe_tex == null
	_layout_battle_stage()

func _animate_strike(attacker_is_hero: bool) -> void:
	var attacker: TextureRect = hero_sprite if attacker_is_hero else foe_sprite
	var home: Vector2 = hero_home if attacker_is_hero else foe_home
	var direction := 1.0 if attacker_is_hero else -1.0
	var distance := maxf(battle_stage.size.x * 0.20, 45.0)
	var tw := create_tween()
	tw.tween_property(attacker, "position:x", home.x + direction * distance, 0.22).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tw.tween_property(attacker, "modulate", Color(1.0, 0.55, 0.45), 0.08)
	tw.tween_property(attacker, "modulate", Color.WHITE, 0.10)
	tw.tween_property(attacker, "position", home, 0.22).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	await get_tree().create_timer(0.64).timeout

func _animate_heal(is_hero: bool) -> void:
	var target: CanvasItem = hero_sprite if is_hero else foe_sprite
	var original := target.modulate
	var tw := create_tween()
	tw.tween_property(target, "modulate", Color(0.45, 1.0, 0.55), 0.18)
	tw.tween_property(target, "modulate", original, 0.28)
	await get_tree().create_timer(0.48).timeout


func _log(t: String) -> void:
	logv.add_line(t)


func _flush(lines: Array) -> void:
	for l in lines:
		logv.add_line(str(l))


# ---------- Интерфейс ----------

func _refresh() -> void:
	var t := "[b][color=#c9a961]%s[/color][/b] ур.%d  HP [color=#e07a5f]%d/%d[/color]  Броня %d%%\n" % [
		P["name"], P["lvl"], P["hp"], P["max_hp"], int(round(Combat.arm_total(P) * 100))]
	t += "[b][color=#c9a961]%s[/color][/b] ур.%d  HP [color=#e07a5f]%d/%d[/color]" % [E["name"], E["lvl"], E["hp"], E["max_hp"]]
	var st: Array = []
	if int(E["eff"]["poison"]) > 0:
		st.append("яд")
	if int(E["eff"]["miss"]) > 0:
		st.append("мыши")
	if int(E["eff"]["nopot"]) > 0:
		st.append("анти-магия")
	if int(E["eff"]["wolf"]) > 0:
		st.append("волк")
	if st.size() > 0:
		t += "  [color=#7fb069](%s)[/color]" % ", ".join(st)
	stats_label.text = t
	Style.clear(bottom)
	if phase == "pick":
		_build_pick()
	elif phase == "turn":
		_build_turn()
	elif phase == "over":
		var back := Style.btn("Продолжить путь", Style.MOSS, 104, 36)
		back.pressed.connect(func(): get_tree().change_scene_to_file("res://scenes/Explore.tscn"))
		bottom.add_child(back)


func _build_pick() -> void:
	var abilities: Array = Combat.ABILITIES.get(str(P.get("id", "gladiator")), Combat.ABILITIES.get("gladiator", []))
	for a in abilities:
		var b := Style.btn("%s · КД %d\n%s" % [a["name"], a["cd"], a["desc"]], Style.PLATE, 92, 29)
		b.pressed.connect(_on_pick.bind(a))
		bottom.add_child(b)


func _combo_text() -> String:
	var parts: Array = []
	for k in queue:
		var s: String = str(k)
		if s == "hit":
			parts.append("Удар")
		elif s == "ability":
			parts.append(str(P["ability"]["name"]))
		else:
			parts.append("Зелье")
	return " + ".join(parts) if parts.size() > 0 else "—"


func _potions_queued(key: String) -> int:
	return queue.count("potion:" + key)


func _build_turn() -> void:
	var info := Label.new()
	info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	info.add_theme_font_size_override("font_size", 25)
	info.add_theme_color_override("font_color", Style.GOLD)
	info.text = "Ход %d. Действий: %d, выбрано: %d\nКомбо: %s" % [turn, actions_total, queue.size(), _combo_text()]
	bottom.add_child(info)
	var free: bool = queue.size() < actions_total

	if potion_menu:
		var plist := Style.fixed_scroll(bottom, int(_controls_height() * 0.52))
		for key in P["potions"]:
			var left: int = int(P["potions"][key]) - _potions_queued(str(key))
			if left <= 0:
				continue
			var pb := Style.btn("%s (%d)\n%s" % [ItemDB.potion_name(str(key)), left, ItemDB.potion_desc(str(key))], Style.MOSS, 92, 29)
			pb.disabled = not free
			pb.pressed.connect(_on_add.bind("potion:" + str(key)))
			plist.add_child(pb)
		var back := Style.btn("Назад", Style.PLATE, 92, 29)
		back.pressed.connect(func():
			potion_menu = false
			_refresh())
		bottom.add_child(back)
		return

	var r1 := Style.row(bottom)
	var hit := Style.btn("УДАР", Style.PLATE, 92, 29)
	hit.disabled = not free
	hit.pressed.connect(_on_add.bind("hit"))
	r1.add_child(hit)
	var any_potion := false
	for key in P["potions"]:
		if int(P["potions"][key]) - _potions_queued(str(key)) > 0:
			any_potion = true
	var pot := Style.btn("ЗЕЛЬЯ", Style.MOSS, 92, 29)
	pot.disabled = (not free) or (not any_potion)
	pot.pressed.connect(func():
		potion_menu = true
		_refresh())
	r1.add_child(pot)
	var ab_text: String = str(P["ability"]["name"])
	if int(P["cd"]) > 0:
		ab_text += "\n(КД %d)" % int(P["cd"])
	var ab := Style.btn(ab_text, Style.BLOOD, 92, 29)
	ab.disabled = (not free) or int(P["cd"]) > 0 or queue.has("ability")
	ab.pressed.connect(_on_add.bind("ability"))
	r1.add_child(ab)

	var r2 := Style.row(bottom)
	var undo := Style.btn("ОТМЕНИТЬ", Style.PLATE, 92, 29)
	undo.disabled = queue.is_empty()
	undo.pressed.connect(_on_undo)
	r2.add_child(undo)
	var end := Style.btn("КОНЕЦ ХОДА", Style.MOSS, 92, 29)
	end.pressed.connect(_end_turn)
	r2.add_child(end)


# ---------- Ввод игрока ----------

func _on_pick(a: Dictionary) -> void:
	P["ability"] = a.duplicate(true)
	P["cd"] = 0
	phase = "turn"
	turn = 1
	_log("Выбрана способность: [color=#c9a961]%s[/color]." % a["name"])
	_roll()
	_refresh()


func _roll() -> void:
	actions_total = Combat.roll_actions(P)
	queue.clear()
	potion_menu = false
	_log("[color=#c9a961]— Ход %d: выпало действий — %d —[/color]" % [turn, actions_total])


func _on_add(kind: String) -> void:
	if queue.size() >= actions_total:
		return
	queue.append(kind)
	potion_menu = false
	_refresh()


func _on_undo() -> void:
	if not queue.is_empty():
		queue.pop_back()
		_refresh()


# ---------- Ход ----------

func _end_turn() -> void:
	if phase != "turn" or queue.is_empty():
		return
	phase = "busy"
	Style.clear(bottom)
	var lines: Array = []
	for k in queue:
		if int(E["hp"]) <= 0:
			break
		var action_key := str(k)
		if action_key == "hit" or action_key == "ability":
			await _animate_strike(true)
		elif action_key.begins_with("potion:"):
			await _animate_heal(true)
		Combat.do_action(P, E, action_key, lines)
	queue.clear()
	if int(E["hp"]) > 0:
		Combat.end_turn(P, E, lines)
	_flush(lines)
	if int(E["hp"]) <= 0:
		_victory()
		return
	var l2: Array = []
	var enemy_will_heal := float(E["hp"]) < float(E["max_hp"]) * 0.30 and int(E.get("enemy_potions", 0)) > 0 and not bool(E["eff"].get("drank", false))
	if enemy_will_heal:
		await _animate_heal(false)
	else:
		await _animate_strike(false)
	Combat.enemy_turn(E, P, l2)
	if int(P["hp"]) > 0:
		Combat.end_turn(E, P, l2)
	_flush(l2)
	if int(P["hp"]) <= 0:
		_defeat()
		return
	turn += 1
	phase = "turn"
	_roll()
	_refresh()


# ---------- Итог боя ----------

func _victory() -> void:
	phase = "over"
	Combat.commit_hero(P)
	var lines: Array = SaveManager.grant_victory(E, str(SaveManager.data["location"]))
	_flush(lines)
	SaveManager.pending_msg = "Вы победили: %s." % E["name"]
	SaveManager.encounter = {}
	SaveManager.save_game()
	if E["boss"] or int(SaveManager.data["level"]) > level_before:
		Online.push_score()
	_refresh()


func _defeat() -> void:
	phase = "over"
	Combat.commit_hero(P)
	_log("[color=#e07a5f][b]Вы пали в бою...[/b][/color]")
	_flush(SaveManager.apply_death())
	_log("Вы приходите в себя в лагере.")
	SaveManager.pending_msg = "Вы очнулись в лагере после поражения."
	SaveManager.encounter = {}
	SaveManager.save_game()
	_refresh()
