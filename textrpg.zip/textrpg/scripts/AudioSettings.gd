extends Control
## Необязательный контроллер для существующей сцены настроек.
## Имена узлов: MusicSlider, SfxSlider, AmbienceSlider (значения 0..100), MuteButton.

@onready var music_slider := get_node_or_null("MusicSlider") as Range
@onready var sfx_slider := get_node_or_null("SfxSlider") as Range
@onready var ambience_slider := get_node_or_null("AmbienceSlider") as Range
@onready var mute_button := get_node_or_null("MuteButton") as BaseButton

func _ready() -> void:
    if music_slider:
        music_slider.value = 70
        music_slider.value_changed.connect(func(v): AudioManager.set_music_volume(v / 100.0))
    if sfx_slider:
        sfx_slider.value = 80
        sfx_slider.value_changed.connect(func(v): AudioManager.set_sfx_volume(v / 100.0))
    if ambience_slider:
        ambience_slider.value = 45
        ambience_slider.value_changed.connect(func(v): AudioManager.set_ambience_volume(v / 100.0))
    if mute_button:
        mute_button.button_pressed = AudioManager.is_muted()
        mute_button.toggled.connect(func(enabled): AudioManager.set_muted(enabled))
