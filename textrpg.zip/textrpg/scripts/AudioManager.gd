extends Node
## Глобальный аудиоменеджер Godot 4. Добавьте в Autoload с именем AudioManager.

const MUSIC_PATHS := {
    "menu": "res://assets/audio/music/music_menu.ogg",
    "exploration": "res://assets/audio/music/music_exploration.ogg",
    "battle": "res://assets/audio/music/music_battle.ogg",
    "boss": "res://assets/audio/music/music_boss.ogg",
}
const AMBIENCE_PATHS := {
    "dungeon": "res://assets/audio/ambience/ambience_dungeon.ogg",
    "forest": "res://assets/audio/ambience/ambience_forest.ogg",
    "arena": "res://assets/audio/ambience/ambience_arena.ogg",
}
const SFX_PATHS := {
    "button_click": "res://assets/audio/sfx/ui/button_click.ogg",
    "button_back": "res://assets/audio/sfx/ui/button_back.ogg",
    "button_error": "res://assets/audio/sfx/ui/button_error.ogg",
    "attack_whoosh": "res://assets/audio/sfx/combat/attack_whoosh.ogg",
    "hit_heavy": "res://assets/audio/sfx/combat/hit_heavy.ogg",
    "hit_critical": "res://assets/audio/sfx/combat/hit_critical.ogg",
    "player_hurt": "res://assets/audio/sfx/characters/player_hurt.ogg",
    "enemy_hurt": "res://assets/audio/sfx/characters/enemy_hurt.ogg",
    "enemy_death": "res://assets/audio/sfx/characters/enemy_death.ogg",
    "potion_drink": "res://assets/audio/sfx/combat/potion_drink.ogg",
    "ability_cast": "res://assets/audio/sfx/combat/ability_cast.ogg",
    "dodge": "res://assets/audio/sfx/combat/dodge.ogg",
    "victory_stinger": "res://assets/audio/sfx/events/victory_stinger.ogg",
    "defeat_stinger": "res://assets/audio/sfx/events/defeat_stinger.ogg",
    "quest_complete": "res://assets/audio/sfx/events/quest_complete.ogg",
    "level_up": "res://assets/audio/sfx/events/level_up.ogg",
    "door_open": "res://assets/audio/sfx/world/door_open.ogg",
    "chest_open": "res://assets/audio/sfx/world/chest_open.ogg",
    "gold_pickup": "res://assets/audio/sfx/world/gold_pickup.ogg",
}

const CROSSFADE_SECONDS := 1.2
const PLAYER_DB := -8.0

var _music_a: AudioStreamPlayer
var _music_b: AudioStreamPlayer
var _active_music: AudioStreamPlayer
var _ambience_player: AudioStreamPlayer
var _sfx_players: Array[AudioStreamPlayer] = []
var _music_generation := 0
var _ambience_generation := 0
var _muted := false

func _ready() -> void:
    _ensure_bus("Music")
    _ensure_bus("SFX")
    _ensure_bus("Ambience")
    _music_a = _make_player("Music")
    _music_b = _make_player("Music")
    _active_music = _music_a
    _ambience_player = _make_player("Ambience")
    for i in range(8):
        _sfx_players.append(_make_player("SFX"))
    _load_settings()

func _ensure_bus(bus_name: String) -> void:
    if AudioServer.get_bus_index(bus_name) >= 0:
        return
    AudioServer.add_bus()
    AudioServer.set_bus_name(AudioServer.bus_count - 1, bus_name)

func _make_player(bus_name: String) -> AudioStreamPlayer:
    var p := AudioStreamPlayer.new()
    p.bus = bus_name
    p.volume_db = PLAYER_DB
    add_child(p)
    return p

func play_music(track: String, fade_seconds: float = CROSSFADE_SECONDS) -> void:
    if not MUSIC_PATHS.has(track):
        push_warning("AudioManager: неизвестный трек: " + track)
        return
    var path: String = MUSIC_PATHS[track]
    if not ResourceLoader.exists(path):
        push_warning("AudioManager: не найден файл " + path)
        return
    _music_generation += 1
    var generation := _music_generation
    var incoming: AudioStreamPlayer = _music_b if _active_music == _music_a else _music_a
    var stream := load(path) as AudioStream
    if stream == null:
        return
    if stream is AudioStreamOggVorbis:
        stream.loop = true
    incoming.stop()
    incoming.stream = stream
    incoming.volume_db = -60.0
    incoming.play()
    var tween := create_tween()
    tween.set_parallel(true)
    tween.tween_property(incoming, "volume_db", PLAYER_DB, maxf(fade_seconds, 0.05))
    if _active_music.playing:
        tween.tween_property(_active_music, "volume_db", -60.0, maxf(fade_seconds, 0.05))
    tween.finished.connect(func():
        if generation != _music_generation:
            return
        if _active_music != incoming:
            _active_music.stop()
        _active_music = incoming
    )

func stop_music(fade_seconds: float = CROSSFADE_SECONDS) -> void:
    _music_generation += 1
    var generation := _music_generation
    var old := _active_music
    if not old.playing:
        return
    var tween := create_tween()
    tween.tween_property(old, "volume_db", -60.0, maxf(fade_seconds, 0.05))
    tween.finished.connect(func():
        if generation == _music_generation:
            old.stop()
    )

func play_ambience(kind: String, fade_seconds: float = 0.8) -> void:
    if not AMBIENCE_PATHS.has(kind):
        push_warning("AudioManager: неизвестная атмосфера: " + kind)
        return
    var path: String = AMBIENCE_PATHS[kind]
    if not ResourceLoader.exists(path):
        push_warning("AudioManager: не найден файл " + path)
        return
    _ambience_generation += 1
    var generation := _ambience_generation
    var stream := load(path) as AudioStream
    if stream == null:
        return
    if stream is AudioStreamOggVorbis:
        stream.loop = true
    _ambience_player.stop()
    _ambience_player.stream = stream
    _ambience_player.volume_db = -60.0
    _ambience_player.play()
    var tween := create_tween()
    tween.tween_property(_ambience_player, "volume_db", PLAYER_DB, maxf(fade_seconds, 0.05))
    tween.finished.connect(func():
        if generation != _ambience_generation:
            return
    )

func stop_ambience(fade_seconds: float = 0.8) -> void:
    _ambience_generation += 1
    var generation := _ambience_generation
    var tween := create_tween()
    tween.tween_property(_ambience_player, "volume_db", -60.0, maxf(fade_seconds, 0.05))
    tween.finished.connect(func():
        if generation == _ambience_generation:
            _ambience_player.stop()
    )

func play_sfx(sound: String, volume_db: float = 0.0, pitch_scale: float = 1.0) -> void:
    if not SFX_PATHS.has(sound):
        push_warning("AudioManager: неизвестный эффект: " + sound)
        return
    var path: String = SFX_PATHS[sound]
    if not ResourceLoader.exists(path):
        push_warning("AudioManager: не найден файл " + path)
        return
    var stream := load(path) as AudioStream
    if stream == null:
        return
    for p in _sfx_players:
        if not p.playing:
            p.stream = stream
            p.volume_db = volume_db
            p.pitch_scale = pitch_scale
            p.play()
            return
    # Если все 8 каналов заняты, не обрываем звучащие эффекты.

func set_music_volume(value: float) -> void:
    _set_bus_volume("Music", value)
    _save_setting("music", value)

func set_sfx_volume(value: float) -> void:
    _set_bus_volume("SFX", value)
    _save_setting("sfx", value)

func set_ambience_volume(value: float) -> void:
    _set_bus_volume("Ambience", value)
    _save_setting("ambience", value)

func _set_bus_volume(bus_name: String, value: float) -> void:
    var index := AudioServer.get_bus_index(bus_name)
    if index >= 0:
        AudioServer.set_bus_volume_db(index, linear_to_db(maxf(clampf(value, 0.0, 1.0), 0.0001)))

func set_muted(enabled: bool) -> void:
    _muted = enabled
    for bus_name in ["Music", "SFX", "Ambience"]:
        var index := AudioServer.get_bus_index(bus_name)
        if index >= 0:
            AudioServer.set_bus_mute(index, enabled)
    _save_setting("muted", enabled)

func is_muted() -> bool:
    return _muted

func _load_settings() -> void:
    var cfg := ConfigFile.new()
    if cfg.load("user://audio_settings.cfg") != OK:
        return
    set_music_volume(float(cfg.get_value("audio", "music", 0.7)))
    set_sfx_volume(float(cfg.get_value("audio", "sfx", 0.8)))
    set_ambience_volume(float(cfg.get_value("audio", "ambience", 0.45)))
    _muted = bool(cfg.get_value("audio", "muted", false))
    for bus_name in ["Music", "SFX", "Ambience"]:
        var index := AudioServer.get_bus_index(bus_name)
        if index >= 0:
            AudioServer.set_bus_mute(index, _muted)

func _save_setting(key: String, value: Variant) -> void:
    var cfg := ConfigFile.new()
    cfg.load("user://audio_settings.cfg")
    cfg.set_value("audio", key, value)
    cfg.save("user://audio_settings.cfg")
