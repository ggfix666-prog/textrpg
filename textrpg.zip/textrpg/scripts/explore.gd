extends Control
# Главный экран пути: «Идти дальше» -> событие (враг, добыча, сундук, алтарь, торговец, кузнец, ведьма).
# Отсюда же: рюкзак, задания, привал, смена локации, онлайн.

const REST_PER_LEVEL := 3

var stats_label: RichTextLabel
var logv
var bottom: VBoxContainer
var bottom_scroll: ScrollContainer
var stage: Control
var background_layer: Control
var background_tiles: Array[Control] = []
var player_sprite: TextureRect
var enemy_sprite: TextureRect
var player_fallback: Label
var enemy_fallback: Label
var walk_tween: Tween
var is_walking: bool = false

# Пути к фонам локаций. Если файла пока нет, используется стилизованный цветной фон.
const LOCATION_BACKGROUND_PATHS := {
    "start": "res://assets/locations/coliseum.jpg",
    "forest": "res://assets/locations/dark_forest.png",
    "ruins": "res://assets/locations/ruins.png",
    "crypt": "res://assets/locations/forgotten_crypt.png",
    "death_halls": "res://assets/locations/halls_of_death.png",
    "dragon": "res://assets/locations/dragon_lair.png",
}

# Пути к портретам классов. Имена файлов можно поменять здесь под свои спрайты.
const CHARACTER_SPRITE_PATHS := {
    "gladiator": "res://assets/characters/gladiator.png",
    "mage": "res://assets/characters/mage.png",
    "vampire": "res://assets/characters/vampire.png",
    "archer": "res://assets/characters/archer.png",
    "hunter": "res://assets/characters/hunter.png",
}

# Словарь спрайтов монстров. Файлы должны лежать в assets/monsters.
const MONSTER_SPRITE_PATHS := {
    "Крыса-мутант": "res://assets/monsters/mutant_rat.png",
    "Гоблин-мародёр": "res://assets/monsters/goblin.png",
    "Одичавший пёс": "res://assets/monsters/feral_dog.png",
    "Гладиатор-новичок": "res://assets/monsters/rookie_gladiator.png",
    "Песчаный скорпион": "res://assets/monsters/sand_scorpion.png",
    "Скелет-воин": "res://assets/monsters/skeleton_warrior.png",
    "Гарпия": "res://assets/monsters/harpy.png",
    "Берсерк": "res://assets/monsters/berserker.png",
    "Минотавр": "res://assets/monsters/minotaur.png",
    "Гигантский паук": "res://assets/monsters/giant_spider.png",
    "Лесной волк": "res://assets/monsters/forest_wolf.png",
    "Разбойник": "res://assets/monsters/bandit.png",
    "Гоблин-лучник": "res://assets/monsters/goblin_archer.png",
    "Кровососущая пиявка": "res://assets/monsters/blood_leech.png",
    "Гриб-мутант": "res://assets/monsters/mutant_mushroom.png",
    "Древень": "res://assets/monsters/treant.png",
    "Король Гоблинов": "res://assets/monsters/goblin_king.png",
    "Скелет-маг": "res://assets/monsters/skeleton_mage.png",
    "Каменный голем": "res://assets/monsters/stone_golem.png",
    "Призрак": "res://assets/monsters/ghost.png",
    "Элементаль воды": "res://assets/monsters/water_elemental.png",
    "Мумия": "res://assets/monsters/mummy.png",
    "Глаз-наблюдатель": "res://assets/monsters/watcher_eye.png",
    "Проклятый жрец": "res://assets/monsters/cursed_priest.png",
    "Лич-Архимаг": "res://assets/monsters/lich_archmage.png",
    "Зомби": "res://assets/monsters/zombie.png",
    "Летучая мышь-вампир": "res://assets/monsters/vampire_bat.png",
    "Упырь": "res://assets/monsters/ghoul.png",
    "Призрак-плакальщица": "res://assets/monsters/wailing_ghost.png",
    "Крысиный король": "res://assets/monsters/rat_king.png",
    "Отрекшийся рыцарь": "res://assets/monsters/forsaken_knight.png",
    "Некромант": "res://assets/monsters/necromancer.png",
    "Граф-Вампир": "res://assets/monsters/vampire_count.png",
    "Демон-пехота": "res://assets/monsters/demon_infantry.png",
    "Адская гончая": "res://assets/monsters/hellhound.png",
    "Суккуб": "res://assets/monsters/succubus.png",
    "Костяной дракон": "res://assets/monsters/bone_dragon.png",
    "Палач": "res://assets/monsters/executioner.png",
    "Огненный элементаль": "res://assets/monsters/fire_elemental.png",
    "Грешник": "res://assets/monsters/sinner.png",
    "Владыка Демонов": "res://assets/monsters/demon_lord.png",
    "Кобольд-копатель": "res://assets/monsters/kobold_miner.png",
    "Ящер-переросток": "res://assets/monsters/giant_lizard.png",
    "Драконорожденный": "res://assets/monsters/dragonborn.png",
    "Саламандра": "res://assets/monsters/salamander.png",
    "Молодой дракон": "res://assets/monsters/young_dragon.png",
    "Огнегривый грифон": "res://assets/monsters/firemane_griffin.png",
    "Древний Дракон": "res://assets/monsters/elder_dragon.png",
}

var mode := "idle"            # idle / encounter / visit / chest / altar / locations / rest
var enemy: Dictionary = {}
var noticed := false
var visit_kind := ""          # trader / smith / witch


func _ready() -> void:
	randomize()
	if SaveManager.data["class_id"] == "":
		get_tree().change_scene_to_file("res://scenes/MainMenu.tscn")
		return
	var cur: Dictionary = WorldData.location(SaveManager.data["location"])
	if int(cur["min_lvl"]) > int(SaveManager.data["level"]):
		SaveManager.data["location"] = "start"
	var col := Style.screen(self, "")
	stats_label = Style.lbl("", 28)
	col.add_child(stats_label)
	_create_visual_stage(col)
	logv = Style.make_log()
	col.add_child(logv)
	bottom_scroll = ScrollContainer.new()
	bottom_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bottom_scroll.size_flags_vertical = Control.SIZE_SHRINK_END
	bottom_scroll.custom_minimum_size.y = _controls_height()
	bottom_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	col.add_child(bottom_scroll)
	bottom = VBoxContainer.new()
	bottom.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bottom.add_theme_constant_override("separation", 8)
	bottom_scroll.add_child(bottom)

	var loc: Dictionary = WorldData.location(SaveManager.data["location"])
	logv.add_line("Вы стоите на тропе. Локация: [color=#c9a961]%s[/color]." % loc["name"])
	if SaveManager.pending_msg != "":
		logv.add_line(SaveManager.pending_msg)
		SaveManager.pending_msg = ""
	_refresh()


func _log(t: String) -> void:
	logv.add_line(t)


func _heal_count() -> int:
	var n := 0
	for k in SaveManager.data["potions"]:
		n += int(SaveManager.data["potions"][k])
	return n


func _refresh() -> void:
	var c: Dictionary = SaveManager.CLASSES[SaveManager.data["class_id"]]
	var lvl: int = SaveManager.data["level"]
	var loc: Dictionary = WorldData.location(SaveManager.data["location"])
	var hf: Dictionary = Combat.hero_fighter()
	var t := "[b][color=#c9a961]%s[/color][/b] ур.%d (опыт %d/%d)\n" % [c["name"], lvl, SaveManager.data["exp"], SaveManager.exp_needed(lvl)]
	t += "HP [color=#e07a5f]%d/%d[/color]  Броня %d%%  Золото [color=#c9a961]%d[/color]  Зелий %d\n" % [
		hf["hp"], hf["max_hp"], int(round(Combat.arm_total(hf) * 100)), SaveManager.data["gold"], _heal_count()]
	t += "%s (побед здесь: %d)" % [loc["name"], SaveManager.kills(loc["id"])]
	if int(SaveManager.data["altar"]) > 0:
		t += "  [color=#7fb069]Благословение: %d боя[/color]" % SaveManager.data["altar"]
	stats_label.text = t
	Style.clear(bottom)
	match mode:
		"idle":
			_build_idle()
		"encounter":
			_build_encounter()
		"visit":
			_build_visit()
		"chest":
			_build_chest()
		"altar":
			_build_altar()
		"locations":
			_build_locations()
		"rest":
			_build_rest()


func _set_mode(m: String) -> void:
	mode = m
	_refresh()


func _go_scene(path: String) -> void:
	SaveManager.save_game()
	get_tree().change_scene_to_file(path)


# Responsive layout: adapts to portrait and landscape without clipping the action buttons.
func _stage_height() -> float:
	var v := get_viewport_rect().size
	return clampf(v.y * (0.25 if v.x <= v.y else 0.34), 180.0, 330.0)

func _controls_height() -> float:
	var v := get_viewport_rect().size
	return clampf(v.y * (0.32 if v.x <= v.y else 0.40), 410.0, 460.0)

func _on_viewport_resized() -> void:
	if stage != null:
		stage.custom_minimum_size.y = _stage_height()
	if bottom_scroll != null:
		bottom_scroll.custom_minimum_size.y = _controls_height()
	_layout_visual_stage()

# ---------- Визуальная сцена исследования ----------

func _create_visual_stage(parent: VBoxContainer) -> void:
	stage = Control.new()
	stage.name = "ExplorationStage"
	stage.custom_minimum_size = Vector2(0, _stage_height())
	stage.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	stage.clip_contents = true
	parent.add_child(stage)
	stage.resized.connect(_layout_visual_stage)
	get_viewport().size_changed.connect(_on_viewport_resized)

	background_layer = Control.new()
	background_layer.name = "Background"
	background_layer.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	background_layer.clip_contents = true
	stage.add_child(background_layer)

	var tile: Control = _make_background_tile()
	background_layer.add_child(tile)
	background_tiles.append(tile)

	player_sprite = TextureRect.new()
	player_sprite.name = "PlayerSprite"
	player_sprite.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	player_sprite.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	player_sprite.mouse_filter = Control.MOUSE_FILTER_IGNORE
	stage.add_child(player_sprite)

	player_fallback = Label.new()
	player_fallback.text = "ГЕРОЙ"
	player_fallback.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	player_fallback.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	player_fallback.add_theme_color_override("font_color", Color("#f3e7c9"))
	player_fallback.add_theme_font_size_override("font_size", 22)
	stage.add_child(player_fallback)

	enemy_sprite = TextureRect.new()
	enemy_sprite.name = "EnemySprite"
	enemy_sprite.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	enemy_sprite.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	enemy_sprite.mouse_filter = Control.MOUSE_FILTER_IGNORE
	enemy_sprite.modulate.a = 0.0
	enemy_sprite.visible = false
	stage.add_child(enemy_sprite)

	enemy_fallback = Label.new()
	enemy_fallback.text = "ВРАГ"
	enemy_fallback.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	enemy_fallback.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	enemy_fallback.add_theme_color_override("font_color", Color("#f3e7c9"))
	enemy_fallback.add_theme_font_size_override("font_size", 22)
	enemy_fallback.modulate.a = 0.0
	enemy_fallback.visible = false
	stage.add_child(enemy_fallback)

	_layout_visual_stage()
	_update_stage_art()


func _make_background_tile() -> Control:
	# У каждого тайла есть цветной запасной фон и TextureRect поверх него.
	# Поэтому можно переключать локации, даже если часть картинок отсутствует.
	var tile := Control.new()
	tile.clip_contents = true
	var fallback := ColorRect.new()
	fallback.name = "FallbackColor"
	fallback.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	fallback.color = _location_fallback_color(str(SaveManager.data.get("location", "start")))
	fallback.mouse_filter = Control.MOUSE_FILTER_IGNORE
	tile.add_child(fallback)
	var image := TextureRect.new()
	image.name = "BackgroundTexture"
	image.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	image.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	image.stretch_mode = TextureRect.STRETCH_SCALE
	image.mouse_filter = Control.MOUSE_FILTER_IGNORE
	tile.add_child(image)
	return tile


func _location_fallback_color(location_id: String) -> Color:
	match location_id:
		"forest": return Color("#172d20")
		"ruins": return Color("#34313d")
		"crypt": return Color("#241e2c")
		"death_halls": return Color("#351b1b")
		"dragon": return Color("#3a2118")
		_: return Color("#49351f")


func _layout_visual_stage() -> void:
	if stage == null:
		return
	var w: float = maxf(stage.size.x, 320.0)
	var h: float = maxf(stage.size.y, 180.0)
	background_layer.size = Vector2(w, h)
	for i in range(background_tiles.size()):
		var tile: Control = background_tiles[i]
		tile.position = Vector2.ZERO
		tile.size = Vector2(w, h)
	player_sprite.position = Vector2(12, 18)
	player_sprite.size = Vector2(w * 0.34, h * 0.88)
	player_fallback.position = Vector2(12, h * 0.62)
	player_fallback.size = Vector2(w * 0.34, 42)
	enemy_sprite.position = Vector2(w * 0.63, 18)
	enemy_sprite.size = Vector2(w * 0.34, h * 0.88)
	enemy_fallback.position = Vector2(w * 0.63, h * 0.62)
	enemy_fallback.size = Vector2(w * 0.34, 42)


func _update_stage_art() -> void:
	if stage == null:
		return
	var loc_id: String = str(SaveManager.data.get("location", "start"))
	var bg_path: String = str(LOCATION_BACKGROUND_PATHS.get(loc_id, ""))
	var bg_texture: Texture2D = load(bg_path) as Texture2D if bg_path != "" and ResourceLoader.exists(bg_path) else null
	for i in range(background_tiles.size()):
		var tile: Control = background_tiles[i]
		var fallback: ColorRect = tile.get_node("FallbackColor") as ColorRect
		var image: TextureRect = tile.get_node("BackgroundTexture") as TextureRect
		fallback.color = _location_fallback_color(loc_id)
		image.texture = bg_texture
		image.visible = bg_texture != null
	var class_id: String = str(SaveManager.data.get("class_id", ""))
	var hero_path: String = str(CHARACTER_SPRITE_PATHS.get(class_id, ""))
	var hero_texture: Texture2D = load(hero_path) as Texture2D if hero_path != "" and ResourceLoader.exists(hero_path) else null
	player_sprite.texture = hero_texture
	player_sprite.visible = hero_texture != null
	player_fallback.visible = hero_texture == null
	_layout_visual_stage()


func _resolve_monster_sprite(monster_name: String) -> String:
	var mapped: String = str(MONSTER_SPRITE_PATHS.get(monster_name, ""))
	if mapped != "" and ResourceLoader.exists(mapped):
		return mapped
	# Удобный запасной вариант для файлов, названных простым ASCII-именем.
	var safe_name: String = monster_name.to_lower().replace(" ", "_").replace("-", "_")
	for ext in ["png", "webp", "jpg", "jpeg"]:
		var candidate: String = "res://assets/monsters/%s.%s" % [safe_name, ext]
		if ResourceLoader.exists(candidate):
			return candidate
	return ""


func _show_enemy_sprite(monster_name: String) -> void:
	if enemy_sprite == null:
		return
	var path: String = _resolve_monster_sprite(monster_name)
	var texture: Texture2D = load(path) as Texture2D if path != "" else null
	enemy_sprite.texture = texture
	enemy_sprite.modulate.a = 0.0
	enemy_sprite.visible = texture != null
	enemy_fallback.text = monster_name if texture == null else ""
	enemy_fallback.modulate.a = 0.0
	enemy_fallback.visible = texture == null
	_layout_visual_stage()
	var tween := create_tween()
	tween.set_parallel(true)
	if texture != null:
		tween.tween_property(enemy_sprite, "modulate:a", 1.0, 0.65)
	else:
		tween.tween_property(enemy_fallback, "modulate:a", 1.0, 0.65)


func _animate_walk() -> void:
	_update_stage_art()
	await get_tree().process_frame
	_layout_visual_stage()
	if background_tiles.is_empty():
		await get_tree().create_timer(2.5).timeout
		return
	var tile: Control = background_tiles[0]
	var image: TextureRect = tile.get_node("BackgroundTexture") as TextureRect
	var original_position: Vector2 = image.position
	var original_scale: Vector2 = image.scale
	var w: float = maxf(stage.size.x, 320.0)
	# Один фон: лёгкий панорамный сдвиг и приближение создают иллюзию пути,
	# не показывая второй Колизей рядом.
	image.position = original_position
	image.scale = original_scale
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(image, "position:x", -w * 0.06, 2.5).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tw.tween_property(image, "scale", Vector2(1.10, 1.10), 2.5).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	if player_sprite.visible:
		tw.tween_property(player_sprite, "position:x", w * 0.06, 1.25).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	await tw.finished
	var back := create_tween()
	back.set_parallel(true)
	back.tween_property(image, "position", original_position, 0.25)
	back.tween_property(image, "scale", original_scale, 0.25)
	if player_sprite.visible:
		back.tween_property(player_sprite, "position:x", 12.0, 0.25)
	await back.finished


# ---------- Кнопки ----------

func _build_idle() -> void:
	var go := Style.btn("Идти дальше", Style.MOSS, 104, 36)
	go.pressed.connect(_on_go)
	bottom.add_child(go)
	var r1 := Style.row(bottom)
	var b1 := Style.btn("Герой и рюкзак")
	b1.pressed.connect(_go_scene.bind("res://scenes/Hero.tscn"))
	r1.add_child(b1)
	var b2 := Style.btn("Задания")
	b2.pressed.connect(_go_scene.bind("res://scenes/Quests.tscn"))
	r1.add_child(b2)
	var r2 := Style.row(bottom)
	var b3 := Style.btn("Привал")
	b3.pressed.connect(_set_mode.bind("rest"))
	r2.add_child(b3)
	var b4 := Style.btn("Локация")
	b4.pressed.connect(_set_mode.bind("locations"))
	r2.add_child(b4)
	var r3 := Style.row(bottom)
	var b5 := Style.btn("Онлайн")
	b5.pressed.connect(_go_scene.bind("res://scenes/OnlineMenu.tscn"))
	r3.add_child(b5)
	var b6 := Style.btn("В меню", Style.BLOOD)
	b6.pressed.connect(_go_scene.bind("res://scenes/MainMenu.tscn"))
	r3.add_child(b6)


func _build_encounter() -> void:
	var agi: int = int(SaveManager.calc_stats()["agi"])
	if enemy["boss"]:
		var fight := Style.btn("К бою!", Style.BLOOD, 104, 36)
		fight.pressed.connect(_start_battle.bind(""))
		bottom.add_child(fight)
	elif noticed:
		var f2 := Style.btn("Сражаться", Style.BLOOD, 104, 36)
		f2.pressed.connect(_start_battle.bind(""))
		bottom.add_child(f2)
		var ch: int = int(round(WorldData.flee_chance(agi) * 100))
		var fl := Style.btn("Сбежать (%d%%)" % ch, Style.PLATE, 92, 29)
		fl.pressed.connect(_on_flee)
		bottom.add_child(fl)
	else:
		var sn := Style.btn("Атака из засады", Style.BLOOD, 92, 29)
		sn.pressed.connect(_start_battle.bind("player"))
		bottom.add_child(sn)
		var fl2 := Style.btn("Обойти врага", Style.PLATE, 92, 29)
		fl2.pressed.connect(_on_flee_free)
		bottom.add_child(fl2)


func _build_visit() -> void:
	var names := {"trader": "Подойти к торговцу", "smith": "Подойти к кузнецу", "witch": "Подойти к ведьме"}
	var go := Style.btn(str(names[visit_kind]), Style.MOSS, 92, 29)
	go.pressed.connect(_open_shop)
	bottom.add_child(go)
	var pass_by := Style.btn("Пройти мимо", Style.PLATE, 92, 29)
	pass_by.pressed.connect(_leave)
	bottom.add_child(pass_by)


func _build_chest() -> void:
	var o := Style.btn("Открыть сундук", Style.MOSS, 92, 29)
	o.pressed.connect(_open_chest)
	bottom.add_child(o)
	var p := Style.btn("Пройти мимо", Style.PLATE, 92, 29)
	p.pressed.connect(_leave)
	bottom.add_child(p)


func _build_altar() -> void:
	var o := Style.btn("Принести жертву (-10% HP)", Style.BLOOD, 92, 29)
	o.pressed.connect(_use_altar)
	bottom.add_child(o)
	var p := Style.btn("Уйти", Style.PLATE, 92, 29)
	p.pressed.connect(_leave)
	bottom.add_child(p)


func _build_locations() -> void:
	var lvl: int = SaveManager.data["level"]
	for l in WorldData.LOCATIONS:
		var ok: bool = lvl >= int(l["min_lvl"])
		var txt: String = str(l["name"])
		if l["id"] == SaveManager.data["location"]:
			txt = "> " + txt
		if not ok:
			txt += " (с %d ур.)" % l["min_lvl"]
		var b := Style.btn(txt, Style.BLOOD if ok else Style.DARK, 92, 29)
		b.disabled = not ok
		b.pressed.connect(_on_pick_location.bind(l["id"]))
		bottom.add_child(b)
	var back := Style.btn("Назад", Style.PLATE, 92, 29)
	back.pressed.connect(_set_mode.bind("idle"))
	bottom.add_child(back)


func _rest_cost() -> int:
	return int(SaveManager.data["level"]) * REST_PER_LEVEL


func _build_rest() -> void:
	var hp: int = SaveManager.data["hp"]
	var mhp: int = SaveManager.max_hp()
	var rest := Style.btn("Отдохнуть: HP до максимума (%d зол.)" % _rest_cost(), Style.MOSS, 92, 29)
	rest.disabled = hp >= mhp
	rest.pressed.connect(_on_rest)
	bottom.add_child(rest)
	var rc: int = SaveManager.repair_cost() * 2
	var rep := Style.btn("Починить снаряжение (%d зол., в лагере x2)" % rc, Style.PLATE, 92, 29)
	rep.disabled = rc <= 0
	rep.pressed.connect(_on_repair)
	bottom.add_child(rep)
	for key in SaveManager.data["potions"]:
		if str(key).begins_with("heal_") and int(SaveManager.data["potions"][key]) > 0:
			var pb := Style.btn("Выпить: %s (%d)" % [ItemDB.potion_name(str(key)), SaveManager.data["potions"][key]], Style.MOSS, 92, 29)
			pb.disabled = hp >= mhp
			pb.pressed.connect(_on_drink.bind(str(key)))
			bottom.add_child(pb)
	var back := Style.btn("Назад", Style.PLATE, 92, 29)
	back.pressed.connect(_set_mode.bind("idle"))
	bottom.add_child(back)


# ---------- Привал и локации ----------

func _on_rest() -> void:
	var cost := _rest_cost()
	if int(SaveManager.data["gold"]) < cost:
		_log("[color=#e07a5f]Не хватает золота на привал.[/color]")
		return
	SaveManager.data["gold"] -= cost
	SaveManager.data["hp"] = SaveManager.max_hp()
	SaveManager.save_game()
	_log("Вы отдыхаете у костра и восстанавливаете силы (-%d золота)." % cost)
	_refresh()


func _on_repair() -> void:
	var cost: int = SaveManager.repair_cost() * 2
	if int(SaveManager.data["gold"]) < cost:
		_log("[color=#e07a5f]Не хватает золота на ремонт.[/color]")
		return
	SaveManager.data["gold"] -= cost
	SaveManager.repair_all()
	SaveManager.save_game()
	_log("Снаряжение починено (-%d золота)." % cost)
	_refresh()


func _on_drink(key: String) -> void:
	var cnt: int = int(SaveManager.data["potions"].get(key, 0))
	if cnt <= 0:
		return
	var tier: int = int(key.split("_")[1]) - 1
	var S: Dictionary = SaveManager.calc_stats()
	var heal_n: int = int(round(int(S["max_hp"]) * float(ItemDB.POTION_VAL["heal"][tier]) * float(S["heal_mult"])))
	var before: int = SaveManager.data["hp"]
	SaveManager.data["potions"][key] = cnt - 1
	if cnt - 1 <= 0:
		SaveManager.data["potions"].erase(key)
	SaveManager.data["hp"] = mini(int(S["max_hp"]), before + heal_n)
	SaveManager.save_game()
	_log("[color=#7fb069]Вы пьёте зелье: +%d HP.[/color]" % (int(SaveManager.data["hp"]) - before))
	_refresh()


func _on_pick_location(id: String) -> void:
	SaveManager.data["location"] = id
	SaveManager.save_game()
	_update_stage_art()
	_log("Вы отправляетесь в локацию: [color=#c9a961]%s[/color]." % WorldData.location(id)["name"])
	_set_mode("idle")


# ---------- События ----------

func _on_go() -> void:
	# Защита от повторного нажатия, пока фон движется.
	if is_walking or mode != "idle":
		return
	is_walking = true
	bottom.visible = false
	if enemy_sprite != null:
		enemy_sprite.visible = false
	if enemy_fallback != null:
		enemy_fallback.visible = false
	await _animate_walk()
	bottom.visible = true
	is_walking = false

	var lvl: int = int(SaveManager.data["level"])
	var loc_id: String = str(SaveManager.data["location"])
	var loc: Dictionary = WorldData.location(loc_id)

	# Сохраняем все существующие события исследования и их вероятности.
	var r: float = randf()
	if r < 0.60:
		_event_enemy(loc, lvl)
	elif r < 0.72:
		_log("Путь свободен. " )
		_event_loot(lvl)
	elif r < 0.76:
		_log("Путь свободен. Среди камней стоит [color=#c9a961]старый сундук[/color]. Он выглядит подозрительно.")
		mode = "chest"
	elif r < 0.80:
		_log("Путь свободен. Вы находите [color=#c9a961]древний алтарь[/color]. Он требует жертвы кровью, взамен даёт силу.")
		mode = "altar"
	elif r < 0.90:
		_visit("trader", "Путь свободен. Вы встречаете [color=#c9a961]бродячего торговца[/color]. Он раскладывает товар на плаще.")
	elif r < 0.95:
		_visit("smith", "Путь свободен. Среди деревьев дымит [color=#c9a961]походная кузница[/color]. Кузнец кивает вам.")
	else:
		_visit("witch", "Путь свободен. Из тумана выходит [color=#c9a961]ведьма[/color] со склянками на поясе.")
	_refresh()


func _visit(kind: String, text: String) -> void:
	visit_kind = kind
	_log(text)
	mode = "visit"


func _open_shop() -> void:
	SaveManager.shop_mode = visit_kind
	if visit_kind == "trader":
		SaveManager.shop_stock = ItemDB.gen_trader_stock(int(SaveManager.data["level"]))
	_go_scene("res://scenes/Shop.tscn")


func _leave() -> void:
	_log("Вы идёте дальше.")
	_set_mode("idle")


func _event_enemy(loc: Dictionary, lvl: int) -> void:
	enemy = WorldData.make_location_enemy(str(loc["id"]), lvl)
	if enemy.is_empty():
		_log("Не удалось создать противника. Проверьте базу MonsterDB.")
		return
	var agi: int = int(SaveManager.calc_stats()["agi"])
	noticed = randf() > WorldData.sneak_chance(agi, enemy)
	var head := "Впереди [color=#c9a961]%s[/color] (ур. %d). " % [enemy["name"], enemy["lvl"]]
	if noticed:
		_log(head + "[color=#e07a5f]Вас заметили![/color]")
	else:
		_log(head + "[color=#7fb069]Вас не заметили.[/color]")
	mode = "encounter"
	_show_enemy_sprite(str(enemy.get("name", "Враг")))


# Пустой путь: немного золота, иногда зелье, самоцвет или руна
func _event_loot(lvl: int) -> void:
	var S: Dictionary = SaveManager.calc_stats()
	var luck: float = float(S["drop"])
	var gold: int = int(round((randi_range(5, 15) + lvl * 2) * (1.0 + float(S["gold"]))))
	SaveManager.add_gold(gold, true)
	var txt := "Путь пуст. В пыли блестит добыча: [color=#c9a961]+%d золота[/color]." % gold
	if randf() < 0.15 * (1.0 + luck):
		SaveManager.add_potion("heal_1", 1)
		txt += " И целое [color=#7fb069]зелье лечения[/color]!"
	elif randf() < 0.08 * (1.0 + luck):
		var g: String = ItemDB.roll_gem()
		if SaveManager.add_gem(g, 1):
			txt += " И самоцвет: [color=#c07bff]%s[/color]!" % ItemDB.GEMS[g]["name"]
	_log(txt)
	SaveManager.save_game()


func _open_chest() -> void:
	var lvl: int = SaveManager.data["level"]
	var r: float = randf()
	if r < 0.55:
		var S: Dictionary = SaveManager.calc_stats()
		var it: Dictionary = ItemDB.gen_drop(lvl + 5, float(S["drop"]) + 0.3)
		_log("Сундук открывается! " + SaveManager._stash_item(it))
		var gold: int = lvl * 8 + randi_range(5, 25)
		SaveManager.add_gold(gold, true)
		_log("Внутри лежит ещё [color=#c9a961]%d золота[/color]." % gold)
	elif r < 0.80:
		var dmg: int = maxi(1, int(int(SaveManager.max_hp()) * randf_range(0.10, 0.20)))
		SaveManager.data["hp"] = maxi(1, int(SaveManager.data["hp"]) - dmg)
		_log("[color=#e07a5f]Ловушка![/color] Из сундука бьёт шип: -%d HP." % dmg)
	else:
		_log("Сундук оказывается пустым. Только паутина.")
	SaveManager.save_game()
	_set_mode("idle")


func _use_altar() -> void:
	var cost: int = maxi(1, int(int(SaveManager.max_hp()) * 0.10))
	SaveManager.data["hp"] = maxi(1, int(SaveManager.data["hp"]) - cost)
	SaveManager.data["altar"] = 3
	SaveManager.save_game()
	_log("Алтарь вспыхивает. [color=#7fb069]Благословение: +15%% урона на 3 боя.[/color] (-%d HP)" % cost)
	_set_mode("idle")


func _on_flee_free() -> void:
	_log("Вы тихо обходите врага стороной.")
	_set_mode("idle")


func _on_flee() -> void:
	var agi: int = int(SaveManager.calc_stats()["agi"])
	if randf() < WorldData.flee_chance(agi):
		_log("[color=#7fb069]Вам удалось ускользнуть.[/color]")
		_set_mode("idle")
	else:
		_log("[color=#e07a5f]Побег не удался![/color] Враг бьёт первым.")
		_start_battle("enemy")


# first: "" — обычный бой, "player" — засада (крит), "enemy" — враг бьёт первым
func _start_battle(first: String) -> void:
	enemy["first"] = first
	SaveManager.encounter = enemy
	_go_scene("res://scenes/Battle.tscn")
