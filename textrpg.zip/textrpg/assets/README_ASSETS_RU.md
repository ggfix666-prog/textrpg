# Папки визуальных ресурсов «Хроники Мрака»

Все изображения локаций, предметов и оружия лучше сохранять в PNG или WebP. Для иконок предметов используйте квадрат 512x512 px с прозрачным фоном, если это возможно.

## Локации — `res://assets/locations/`
- `coliseum.png` — Колизей (id локации `start`)
- `dark_forest.png` — Тёмный Лес (`forest`)
- `ruins.png` — Руины (`ruins`)
- `forgotten_crypt.png` — Забытый Склеп (`crypt`)
- `halls_of_death.png` — Чертоги Смерти (`death_halls`)
- `dragon_lair.png` — Логово Дракона (`dragon`)

## Монстры — `res://assets/monsters/`
Названия файлов — латиницей в snake_case, например `mutant_rat.png`, `minotaur.png`, `ancient_dragon.png`. Путь картинки затем вписывается в поле `sprite_path` конкретного монстра в `scripts/Monster.gd`.

## Оружие — `res://assets/weapons/`
Примеры: `iron_sword.png`, `wooden_bow.png`, `arcane_staff.png`.

## Предметы — `res://assets/items/`
Примеры: `health_potion.png`, `ruby.png`, `ancient_rune.png`, `leather_armor.png`.

## Интерфейс и эффекты
- `res://assets/ui/` — рамки, кнопки, панели и значки интерфейса.
- `res://assets/effects/` — вспышки, магия, попадания и другие эффекты.
- `res://assets/heroes/` — портреты классов героя (не сами монстры).

Пустые папки содержат `.gitkeep`, чтобы сохраняться в архиве. Изображения пока не подключены к интерфейсу — это следующий визуальный этап после проверки игрового цикла.

## Спрайты экрана исследования

Фоны локаций (PNG):
- `assets/locations/coliseum.png`
- `assets/locations/dark_forest.png`
- `assets/locations/ruins.png`
- `assets/locations/forgotten_crypt.png`
- `assets/locations/halls_of_death.png`
- `assets/locations/dragon_lair.png`

Персонажи классов (PNG): `assets/characters/gladiator.png`, `mage.png`, `vampire.png`, `archer.png`, `hunter.png`.

Спрайты монстров ожидаются в `assets/monsters/`. Полный словарь соответствия имён мобов файлам находится в `scripts/explore.gd` в константе `MONSTER_SPRITE_PATHS`. Например, «Гоблин-мародёр» использует `assets/monsters/goblin.png`.

Если какой-то файл ещё не добавлен, игра продолжит работать: для персонажа будет подпись «ГЕРОЙ», для противника — его имя, а для фона — цветной фон локации.
